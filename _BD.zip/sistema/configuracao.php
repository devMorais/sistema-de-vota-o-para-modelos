<?php

use sistema\Nucleo\Helpers;

date_default_timezone_set('America/Sao_Paulo');

define('SITE_NOME', 'Votação');
define('SITE_DESCRICAO', 'Modelos - Sistema de votação online');

define('URL_PRODUCAO', 'https://hom-votar.devmorais.com.br/');
define('URL_DESENVOLVIMENTO', 'https://votar.test/');
define('SERVIDORES_LOCAIS', ['localhost', '127.0.0.1', 'votar.test']);
define('URL_INICIAL', 'votar');
define('STATUS_ATIVO', 1);
define('STATUS_INATIVO', 0);

if (Helpers::localhost()) {
    define('DB_HOST', 'localhost');
    define('DB_PORTA', '3306');
    define('DB_NOME', 'votar');
    define('DB_USUARIO', 'root');
    define('DB_SENHA', 'root');

    define('URL_SITE', '/');
    define('URL_ADMIN', '/admin/');

    // Asaas
    define('ASAAS_KEY', '$aact_hmlg_000MzkwODA2MWY2OGM3MWRlMDU2NWM3MzJlNzZmNGZhZGY6OmFkNjFiMWNhLTgwMmEtNDdiNy04Y2VjLTlkZTBhMjAxMzc0NDo6JGFhY2hfMTQ0ODU1MzAtNzAxOS00ZTBkLWIzYTAtOWVmZWQ4ZGJhZGJj');
    define('ASAAS_URL', 'https://sandbox.asaas.com/api/v3');
    define('ASAAS_SSL', false);

    // InfinitePay
    define('INFINITEPAY_HANDLE', 'fe_guiar92');
    define('INFINITEPAY_URL', 'https://api.infinitepay.io');
    define('INFINITEPAY_WEBHOOK_URL', 'https://votar.test/webhook/infinitepay');
    define('INFINITEPAY_REDIRECT_URL', null);
    define('INFINITEPAY_SSL', false);
} else {
    define('DB_HOST', 'localhost');
    define('DB_PORTA', '3306');
    define('DB_NOME', 'u846585591_votar_hom');
    define('DB_USUARIO', 'u846585591_votar_hom');
    define('DB_SENHA', 'Caita92*/');

    define('URL_SITE', '/');
    define('URL_ADMIN', '/admin/');

    // Asaas
    define('ASAAS_KEY', '$aact_hmlg_000MzkwODA2MWY2OGM3MWRlMDU2NWM3MzJlNzZmNGZhZGY6OmFkNjFiMWNhLTgwMmEtNDdiNy04Y2VjLTlkZTBhMjAxMzc0NDo6JGFhY2hfMTQ0ODU1MzAtNzAxOS00ZTBkLWIzYTAtOWVmZWQ4ZGJhZGJj');
    define('ASAAS_URL', 'https://sandbox.asaas.com/api/v3');
    define('ASAAS_SSL', true);

    // InfinitePay - PRODUÇÃO
    define('INFINITEPAY_HANDLE', 'fe_guiar92');
    define('INFINITEPAY_URL', 'https://api.infinitepay.io');
    define('INFINITEPAY_WEBHOOK_URL', 'https://hom-votar.devmorais.com.br/webhook/infinitepay');
    define('INFINITEPAY_REDIRECT_URL', null);
    define('INFINITEPAY_SSL', true);
}

define('EMAIL_HOST', 'smtp.hostinger.com');
define('EMAIL_PORTA', '465');
define('EMAIL_USUARIO', '');
define('EMAIL_SENHA', '');
define('EMAIL_REMETENTE', ['email' => EMAIL_USUARIO, 'nome' => SITE_NOME]);
