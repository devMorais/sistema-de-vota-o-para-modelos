<?php
error_reporting(E_ALL & ~E_DEPRECATED);
//Arquivo index responsável pela inicialização do sistema


require_once 'vendor/autoload.php';
require_once 'rotas.php';
